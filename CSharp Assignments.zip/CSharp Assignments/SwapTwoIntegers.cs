﻿using System;

namespace SwapTwoIntegers
{
    class Program
    {
        public static void SwapNumbers(int num1, int num2)
        {
            int temp = 0;
            // logic to swap two numbers
            temp = num1;
            num1 = num2;
            num2 = temp;

            Console.WriteLine("Now the 1st number is : {0} , and the 2nd number is : {1}", num1, num2);
        }
        static void Main(string[] args)
        {
            try 
            {
                Console.WriteLine("Enter the First Number: ");
                int n1 = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the Second Number: ");
                int n2 = int.Parse(Console.ReadLine());

                Program.SwapNumbers(n1, n2);
            }
            catch (Exception e)
            {
                Console.WriteLine("Please enter the numbers..");
            }


        }
    }
}