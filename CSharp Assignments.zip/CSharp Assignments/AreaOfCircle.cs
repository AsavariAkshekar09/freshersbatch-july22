﻿using System;

namespace Circle
{
    class AreaOfCircle
    {
        float area;
        float cicumference;
        public void getCircle(float radius)
        {
            const float pi = 3.14f;
            area = pi * radius * radius;
            cicumference = 2 * pi * radius;

            Console.WriteLine("The Area of the Circle is: {0}", area);
            Console.WriteLine("The Circumference of the Circle is: {0}", cicumference);
        }
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter the radius of the Circle: ");
                float r = float.Parse(Console.ReadLine());
                AreaOfCircle obj = new AreaOfCircle();
                obj.getCircle(r);
            }
            catch(Exception e)
            {
                Console.WriteLine("Error Occured..Please enter the radius in the numeric format.");
            }
            
        }
    }
}