﻿using System;
using System.Collections.Generic;
namespace GenericStack
{
    class MyStack
    {
        public static void Main()
        {
            Customers c1 = new Customers()
            {
                ID = 101,
                Name = "Asavari",
                Gender = "Female"
            };

            Customers c2 = new Customers()
            {
                ID = 102,
                Name = "Shama",
                Gender = "Female"
            };

            Customers c3 = new Customers()
            {
                ID = 103,
                Name = "Prameet",
                Gender = "Male"
            };

            Customers c4 = new Customers()
            {
                ID = 104,
                Name = "Rutik",
                Gender = "Male"
            };

            Stack<Customers> custStack = new Stack<Customers>();
            custStack.Push(c1);
            custStack.Push(c2);
            custStack.Push(c3);
            custStack.Push(c4);
      

            Console.WriteLine("Customers pushed on the Stack are:\n");    
            foreach(Customers c in custStack)
            {
                Console.WriteLine("ID: " + c.ID + " Name: "+ c.Name + " " + "Gender: "+ c.Gender);
            }

            Console.WriteLine("--------------------------");

            Console.WriteLine("Customers poped from the Stack are:");
            Customers cust1 = custStack.Pop();
            Console.WriteLine("ID: " + cust1.ID + " Name: " + cust1.Name + " " + "Gender: " + cust1.Gender);
            
            Console.WriteLine("\nCount of Items left in the Stack: {0}", custStack.Count);

            Customers top = custStack.Peek();
            Console.Write("Item at the top is: ");
            Console.WriteLine(top.ID + "-" + top.Name + "-" + top.Gender);

            Console.WriteLine("\nStack Contains c4?: {0}", custStack.Contains(c4));

            Console.WriteLine("Stack Cleared");
            custStack.Clear();

            Console.WriteLine("Count of Items left in the Stack: {0}", custStack.Count);


            
            // Create a copy of the stack, using the ToArray method and the
            // constructor that accepts an IEnumerable<T>.

            //Stack<object> stack2 = new Stack<object>(custStack.ToArray());

            //Console.WriteLine("\nContents of the first copy:");
            //foreach (object item in stack2)
            //{
            //    Console.WriteLine(item);
            //}


            Console.ReadLine();
        }
    }
    public class Customers
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }   
    }
}

