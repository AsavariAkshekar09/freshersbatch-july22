﻿using System;

namespace BookStruct
{
    public struct BookStructure
    {
        public int bookId;
        public string title;
        public int price;

        public enum bookType
        {
            Magazine = 1,
            Novel = 2,
            ReferenceBook = 3,
            Miscellaneous = 4
        }

        public static void Details()
        {
            Console.WriteLine("-------Accepting the details-------");

            Console.WriteLine("Enter the bookId:");
            int bookID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Book Title:");
            string title = Console.ReadLine();
            Console.WriteLine("Enter the Book Price:");
            int price = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Book Type in Code:");
            int code = int.Parse(Console.ReadLine());

            Console.WriteLine("-------Displaying the details-------");

            Console.WriteLine("The bookId is: {0}", bookID);
            Console.WriteLine("The Book Title is: {0}", title);
            Console.WriteLine("The Book Price is: {0}", price);
            Console.WriteLine("The Book Type is: {0}", (bookType)code);
        }


    }
    class Program
    {
        static void Main(string[] args)
        {
            BookStructure.Details();
        }
    }
}