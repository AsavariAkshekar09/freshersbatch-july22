﻿using System;

namespace StudentMarks
{
    class StudentMarks
    {
        public static void Main(string[] args)
        {
            // To display the average and highest marks obtained

            int[] students = new int[5];
            int sum = 0;
            float average = 0;
            float highest = 0;

            Console.WriteLine("Enter the marks of 5 students: ");

            for (int i = 0; i < students.Length; i++)
            {
                try
                {
                    int marks = int.Parse(Console.ReadLine());
                    students[i] = marks;
                    sum = sum + marks;

                    average = sum / students.Length;
                    if (students[i] > highest)
                    {
                        highest = students[i];
                    }
                }
                catch(IndexOutOfRangeException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch(Exception e)
                {
                    Console.WriteLine("Please enter the marks in numeric format...");
                }

            }

            Console.WriteLine("Average of Marks obtained by 5 students: {0}", average);
            Console.WriteLine("Highest Marks Obtained: {0}", highest);


        }
    }
}