﻿using System;

namespace Calculator
{
    class Calculate
    {
        public static void Addition(int a, int b)
        {
            int result = a + b;
            Console.WriteLine("Addition result is: {0}", result);
        }
        public static void Subtraction(int a, int b)
        {
            int result = a - b;
            Console.WriteLine("Subtraction result is: {0}", result);
        }
        public static void Multiplication(int a, int b)
        {
            int result = a * b;
            Console.WriteLine("Multiplication result is: {0}", result);
        }
        public static void Division(int a, int b)
        {
            try
            {
                int result = a / b;
                Console.WriteLine("Division result is: {0}", result);
            }
            catch(DivideByZeroException e)
            {
                Console.WriteLine("Cannot Divide by 0. Please try again..");
        }
         
        }
        static void Main(string[] args)
        {
            // Write a Program to perform the Operations (Add,Sub,Mult,Div)
            string confirm;
            try
            {
                do
                {

                    Console.WriteLine("Enter the first number: ");
                    int num1 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the second number: ");
                    int num2 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the Operation you want to perform from the following\n(Addition/Subtraction/Multiplication/Division):");
                    string op = Console.ReadLine();

                    if (op.Equals("Addition"))
                    {
                        Calculate.Addition(num1, num2);
                    }
                    else if (op.Equals("Subtraction"))
                    {
                        Calculate.Subtraction(num1, num2);
                    }
                    else if (op.Equals("Multiplication"))
                    {
                        Calculate.Multiplication(num1, num2);
                    }
                    else if (op.Equals("Division"))
                    {
                        Calculate.Division(num1, num2);
                    }
                    else
                    {
                        Console.WriteLine("Invalid Operation!");
                    }

                    Console.WriteLine("Do you want to Perform any other operation (Yes/No): ");
                    confirm = Console.ReadLine().ToLower();

                } while (confirm == "yes");
            }
            catch 
            {
                Console.WriteLine("Please enter a number...");
            }
            

            Console.WriteLine("Exit....");

        }
    }
}
