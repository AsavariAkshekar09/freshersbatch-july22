﻿using System;

namespace SumOfIntegers
{
    class Program
    {

        public static void Sum()
        {
            try
            {
                Console.WriteLine("Enter the number of items you want to insert: ");
                int num = int.Parse(Console.ReadLine());

                int[] my_array = new int[num];
                int total = 0;

                Console.WriteLine("Enter the list of numbers: ");

                for (int i = 0; i < num; i++)
                {
                    int data = int.Parse(Console.ReadLine());
                    my_array[i] = data;
                    total = total + data;
                }

                Console.WriteLine("The sum of all the integers inside an array is: {0}", total);
            }
            catch(IndexOutOfRangeException e)
            {
                Console.WriteLine(e.Message);   
            }
            catch(Exception e)
            {
                Console.WriteLine("Please enter the numbers..");
            }
           
        }
        static void Main(string[] args)
        {
            Program.Sum();
        }
    }
}