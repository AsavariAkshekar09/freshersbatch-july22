﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEnumerableAss5
{
    public class Player
    {
        public string playerName { get; set; }
        public int runs { get; set; }

        public Player(string playerName, int runs)
        {
            this.playerName = playerName;
            this.runs = runs;
        }
    }

    public class Team:IEnumerable
    {
        Player[] playerArray = new Player[4];

        public Team()
        {
            playerArray[0] = new Player("Virat Kholi",78);
            playerArray[1] = new Player("Sachin Tendulakar", 100);
            playerArray[2] = new Player("MS Dhoni", 90);
            playerArray[3] = new Player("KL Rahul", 50);
        }

        public IEnumerator GetEnumerator()     //method
        {
            foreach (Player p in playerArray)
            {
                Console.WriteLine("Player Name is {0} and Runs are {1}", p.playerName, p.runs);
            }
            return playerArray.GetEnumerator();
        }       


    }
    public class Program
    {
        public static void Main()
        {
            Team India = new Team();
            India.GetEnumerator();

            Console.ReadLine();
        }
    }
}