﻿using System;
using System.Collections.Generic;

namespace Assignment5_CSharp3
{
    public class Employee
    {
        public int EmpID { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }
    }
    
    public class Program
    {
        public static void Main()
        {
            Employee empObj = new Employee()
            {
                EmpID = 1,
                Name = "Asavari",
                Salary = 35000
            };
             
            List<Employee> empList = new List<Employee>(1);
            empList.Add(empObj);

            foreach (Employee emp in empList)
            {
                Console.WriteLine("Employee ID: {0}" + " Name: {1}" + " Salary: {2}",emp.EmpID,emp.Name,emp.Salary );
            }

            string confirm;
            Console.WriteLine("----Add a New Employee----\n");

            do
            {
                Employee employeen = new Employee();
                Console.WriteLine("Enter your employee id");
                employeen.EmpID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter employee name");
                employeen.Name = Console.ReadLine();
                Console.WriteLine("Enter employee salary");
                employeen.Salary = Convert.ToInt32(Console.ReadLine());

                empList.Add(employeen);
                Console.WriteLine("Do you want to add any Employee? yes/no: ");
                confirm = Console.ReadLine().ToLower();

            } while (confirm == "yes");

            Console.WriteLine("Total Number of Employees are: {0}", empList.Count);

            Console.WriteLine("Employees in the List are as Follows:");

            foreach (Employee emp in empList)
            {
                Console.WriteLine("Employee ID: {0}" + " Name: {1}" + " Salary: {2}", emp.EmpID, emp.Name, emp.Salary);
            }


            Console.ReadLine();


        }
    }
        
   
}
