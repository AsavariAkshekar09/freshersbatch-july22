﻿using System;
using System.IO;

namespace FileHandling
{
    public class Program
    {
        static void Main(string[] args)
        {
            string path = @"C:\Capgemini\C#-DotNet-Part1\data1.txt";  //verbatim literal
            
            if(File.Exists(path))
            {
                Console.WriteLine("File Found..");
                string readData = File.ReadAllText(path);
                Console.WriteLine("Test Inside the File is:\n{0}",readData);
            }
            else
            {
                Console.WriteLine("No file");
            }

            Console.WriteLine("\n---------All about File---------");

            string path2 = @"C:\Capgemini\C#-DotNet-Part1\TestFile1.txt";

            FileInfo fl = new FileInfo(path2);
            File.Create(path2);
            {
                Console.WriteLine("File has been created");
            }
            
             
            FileInfo fi = new FileInfo(@"C:\Capgemini\C#-DotNet-Part1\TestFileCreatedWithText.txt");
            StreamWriter str = fi.CreateText();
            str.WriteLine("Text inserted");
            Console.WriteLine("File has been created with text");
            str.Close();

            fi.Delete();
            Console.WriteLine("File has been deleted");

            string path3 = @"C:\Capgemini\C#-DotNet-Part1\File3.txt";
            string path4 = @"C:\Capgemini\C#-DotNet-Part1\File4.txt";
            FileInfo fi3 = new FileInfo(path);
            FileInfo fi4 = new FileInfo(path2);
            fi3.MoveTo(path3);
            Console.WriteLine("{0} was copied to {1}.", path3, path4);


            
            Console.WriteLine("\n----------All about Directory---------");

            string dirPath = @"C:\Capgemini\C#-DotNet-Part1\New Directory1";
            string dirPath2 = @"C:\Capgemini\C#-DotNet-Part1\New Directory2";
            string dirPath3 = @"C:\Capgemini\C#-DotNet-Part1\Directory\New 1";

            DirectoryInfo dir = new DirectoryInfo(dirPath3);

            // Properties
            Console.WriteLine(dir.Name);
            Console.WriteLine(dir.FullName);
            Console.WriteLine(dir.LastAccessTime);
            Console.WriteLine(dir.CreationTime);
            Console.WriteLine(dir.Attributes);
            Console.WriteLine(dir.Parent);
            Console.WriteLine(dir.Root);

            DirectoryInfo[] dirs = dir.GetDirectories();
            foreach(var item in dirs)
            {
               Console.WriteLine(item);
               Console.WriteLine(item.FullName);
               Console.WriteLine(item.GetFiles().Length);
            }

            //Methods 
            dir.Delete(true);  // deletes the New Directory2 
            Console.WriteLine("Directory Deleted");
            dir.Create();
            dir.CreateSubdirectory("New Subdirectory1");
            Console.WriteLine("Directory Created");
            dir.MoveTo(dirPath2);          // Moves data from path1 into path2
            Console.WriteLine("Directory Moved");

            

            Console.ReadLine();
        }
    }
}