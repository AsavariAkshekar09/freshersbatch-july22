﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using LitwareLib;

namespace Assignment5_CSharp1
{
    public class EmployeeManagementApplication
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee();
            Employee emp2 = new Employee();
            Employee emp3 = new Employee();

            emp1.setEmpDetails(101,"Asavari",20000);
            emp2.setEmpDetails(102, "Shama", 15000);
            emp3.setEmpDetails(103, "Ritu", 12000);

            ArrayList empList = new ArrayList();
            empList.Add(emp1);
            empList.Add(emp2);  
            empList.Add(emp3);
            Console.WriteLine("Displaying Employee Details from Employee Array List: ");
            
            foreach(Employee employee in empList)
            {
                Console.WriteLine($"ID: {employee._EmpNo} \t Name: {employee._EmpName} \t Salary: {employee._Salary}");
            }
            Console.ReadLine();
        }
    }
}
